package mypack;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConnectionProvider {
	static Properties Prop;
	
	static
	{
		Prop=new Properties();
		//loading properties
		try
		{
			
			//obtaining inputStream for db.properties using
			//get Resources stream() method of java.lang class
			//this method search the given resource as in the folder listed in class path
			
			InputStream in=ConnectionProvider.class.getClassLoader().getResourceAsStream("db.properties");
			Prop.load(in);
			}
		
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}
	//method to create and return connection

	public static Connection getConnection() throws Exception
	{
		Connection con=null;
		Class.forName(Prop.getProperty("driverclass"));
		con=DriverManager.getConnection(Prop.getProperty("url"),Prop.getProperty("user"),Prop.getProperty("password"));
	//	System.out.println(con.toString());
		return con;		
		
	}
	
		

		
		
	}
	

