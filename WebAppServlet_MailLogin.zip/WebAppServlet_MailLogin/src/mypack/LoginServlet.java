package mypack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet 

{
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		try
		{
			String m=request.getParameter("mailid");
			String p=request.getParameter("password");
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
			Connection con=ConnectionProvider.getConnection();// create new class for Connection
			PreparedStatement stmt=con.prepareStatement("select * from usermaster where mailid=? and password=?");
			stmt.setString(1,m);
			stmt.setString(2,p);
			ResultSet rs=stmt.executeQuery();
			if(rs.next())
			{
				out.println("welcome,<b>"+rs.getString(2)+"</b><br>");
				out.print("<a href=logoutServlet>logout</a>");
				
			}
			else
			{
				out.print("<b>Invalid mailid or password.<br><br/> ");
				RequestDispatcher rd=request.getRequestDispatcher("index.html");
				rd.include(request, response);
				
				
			}
			con.close();
			con.close();
				
		}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		
	}
}
